package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.media.RingtoneManager
import android.net.http.SslError
import android.os.Build
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.JsResult
import android.webkit.SslErrorHandler
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

  companion object {
    const val CHANNEL_ID = "zoxara_orders_channel"
    const val CHANNEL_NAME = "New Order Alerts"
    const val EXTRA_ORDER_ID = "EXTRA_OPEN_ORDER_ID"
    const val EXTRA_ORDER_INDEX = "EXTRA_OPEN_ORDER_INDEX"
  }

  var activeWebView: WebView? = null
  private var pendingOrderNotification: Pair<String, Int>? = null

  private val requestPermissionLauncher = registerForActivityResult(
    ActivityResultContracts.RequestPermission()
  ) { isGranted: Boolean ->
    activeWebView?.evaluateJavascript(
      "window.onAndroidNotificationPermissionResult && window.onAndroidNotificationPermissionResult($isGranted);",
      null
    )
  }

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    createNotificationChannel()
    extractOrderIntent(intent)

    setContent {
      MyApplicationTheme {
        Box(
          modifier = Modifier
            .fillMaxSize()
            .background(androidx.compose.ui.graphics.Color(0xFF090A0F))
            .statusBarsPadding()
        ) {
          AdminPortalWebView(this@MainActivity)
        }
      }
    }
  }

  override fun onNewIntent(intent: Intent) {
    super.onNewIntent(intent)
    setIntent(intent)
    extractOrderIntent(intent)
    dispatchPendingOrderToWebView()
  }

  private fun extractOrderIntent(intent: Intent?) {
    val orderId = intent?.getStringExtra(EXTRA_ORDER_ID)
    val orderIndex = intent?.getIntExtra(EXTRA_ORDER_INDEX, -1) ?: -1
    if (!orderId.isNullOrEmpty() || orderIndex >= 0) {
      pendingOrderNotification = Pair(orderId ?: "", orderIndex)
    }
  }

  fun dispatchPendingOrderToWebView() {
    val pending = pendingOrderNotification ?: return
    activeWebView?.post {
      val (orderId, orderIndex) = pending
      val script = "if (window.handleOpenOrderNotification) { window.handleOpenOrderNotification('$orderId', $orderIndex); }"
      activeWebView?.evaluateJavascript(script, null)
      pendingOrderNotification = null
    }
  }

  private fun createNotificationChannel() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
      val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
      val channel = NotificationChannel(
        CHANNEL_ID,
        CHANNEL_NAME,
        NotificationManager.IMPORTANCE_HIGH
      ).apply {
        description = "Instant notifications when new customer orders are received"
        enableLights(true)
        lightColor = Color.parseColor("#A855F7")
        enableVibration(true)
        vibrationPattern = longArrayOf(0, 250, 150, 250)
      }
      notificationManager?.createNotificationChannel(channel)
    }
  }

  fun isNotificationPermissionGranted(): Boolean {
    return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      ContextCompat.checkSelfPermission(
        this,
        Manifest.permission.POST_NOTIFICATIONS
      ) == PackageManager.PERMISSION_GRANTED
    } else {
      NotificationManagerCompat.from(this).areNotificationsEnabled()
    }
  }

  fun requestNotificationPermission() {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
      if (!isNotificationPermissionGranted()) {
        requestPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
      }
    }
  }

  fun showOrderNotification(
    orderId: String,
    customerName: String,
    totalAmount: String,
    orderIndex: Int
  ) {
    if (!isNotificationPermissionGranted()) {
      requestNotificationPermission()
    }

    val intent = Intent(this, MainActivity::class.java).apply {
      flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
      putExtra(EXTRA_ORDER_ID, orderId)
      putExtra(EXTRA_ORDER_INDEX, orderIndex)
    }

    val reqCode = if (orderId.isNotEmpty()) Math.abs(orderId.hashCode()) else System.currentTimeMillis().toInt()
    val pendingIntent = PendingIntent.getActivity(
      this,
      reqCode,
      intent,
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )

    val defaultSoundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)

    val notification = NotificationCompat.Builder(this, CHANNEL_ID)
      .setSmallIcon(R.mipmap.ic_launcher)
      .setContentTitle("New Order Received! 📦 #$orderId")
      .setContentText("$customerName • $totalAmount")
      .setStyle(
        NotificationCompat.BigTextStyle()
          .setBigContentTitle("New Order Received! 📦")
          .bigText("Order ID: #$orderId\nCustomer: $customerName\nTotal: $totalAmount\n\nTap to view order details & chat.")
      )
      .setPriority(NotificationCompat.PRIORITY_HIGH)
      .setCategory(NotificationCompat.CATEGORY_MESSAGE)
      .setSound(defaultSoundUri)
      .setVibrate(longArrayOf(0, 250, 150, 250))
      .setAutoCancel(true)
      .setContentIntent(pendingIntent)
      .build()

    try {
      NotificationManagerCompat.from(this).notify(reqCode, notification)
    } catch (e: SecurityException) {
      // Permission not yet granted on runtime
    }
  }
}

class AndroidNotificationBridge(
  private val activity: MainActivity,
  private val webView: WebView
) {
  @JavascriptInterface
  fun postOrderNotification(
    orderId: String,
    customerName: String,
    totalAmount: String,
    orderIndex: Int
  ) {
    activity.runOnUiThread {
      activity.showOrderNotification(orderId, customerName, totalAmount, orderIndex)
    }
  }

  @JavascriptInterface
  fun requestNotificationPermission() {
    activity.runOnUiThread {
      activity.requestNotificationPermission()
    }
  }

  @JavascriptInterface
  fun isNotificationPermissionGranted(): Boolean {
    return activity.isNotificationPermissionGranted()
  }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
fun AdminPortalWebView(activity: MainActivity) {
  var webViewInstance by remember { mutableStateOf<WebView?>(null) }

  BackHandler(enabled = webViewInstance?.canGoBack() == true) {
    webViewInstance?.goBack()
  }

  AndroidView(
    modifier = Modifier.fillMaxSize(),
    factory = { context ->
      WebView(context).apply {
        webViewInstance = this
        activity.activeWebView = this
        layoutParams = ViewGroup.LayoutParams(
          ViewGroup.LayoutParams.MATCH_PARENT,
          ViewGroup.LayoutParams.MATCH_PARENT
        )
        setBackgroundColor(Color.parseColor("#090A0F"))

        // Allow Android system to manage rendering layer appropriately
        setLayerType(View.LAYER_TYPE_NONE, null)

        settings.apply {
          javaScriptEnabled = true
          domStorageEnabled = true
          databaseEnabled = true
          allowFileAccess = true
          allowContentAccess = true
          loadWithOverviewMode = true
          useWideViewPort = true
          cacheMode = WebSettings.LOAD_DEFAULT
          mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
          displayZoomControls = false
          builtInZoomControls = false
          mediaPlaybackRequiresUserGesture = false
        }

        addJavascriptInterface(
          AndroidNotificationBridge(activity, this),
          "AndroidNotifications"
        )

        webChromeClient = object : WebChromeClient() {
          override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
            return super.onConsoleMessage(consoleMessage)
          }

          override fun onJsAlert(
            view: WebView?,
            url: String?,
            message: String?,
            result: JsResult?
          ): Boolean {
            return super.onJsAlert(view, url, message, result)
          }

          override fun onJsConfirm(
            view: WebView?,
            url: String?,
            message: String?,
            result: JsResult?
          ): Boolean {
            return super.onJsConfirm(view, url, message, result)
          }
        }

        webViewClient = object : WebViewClient() {
          override fun onPageFinished(view: WebView?, url: String?) {
            super.onPageFinished(view, url)
            activity.dispatchPendingOrderToWebView()
          }

          override fun onReceivedSslError(
            view: WebView?,
            handler: SslErrorHandler?,
            error: SslError?
          ) {
            handler?.proceed()
          }

          override fun shouldOverrideUrlLoading(
            view: WebView?,
            request: WebResourceRequest?
          ): Boolean {
            val url = request?.url?.toString() ?: ""
            if (url.startsWith("tel:") || url.startsWith("https://wa.me") || url.startsWith("whatsapp:")) {
              try {
                val intent = Intent(Intent.ACTION_VIEW, request?.url)
                context.startActivity(intent)
                return true
              } catch (e: Exception) {
                // Ignore if third-party app not installed
              }
            }
            return false
          }
        }

        loadUrl("file:///android_asset/index.html")
      }
    }
  )
}


