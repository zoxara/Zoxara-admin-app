package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Gold EA Studio", appName)
  }

  @Test
  fun `mql5 generator produces valid expert advisor script`() {
    val config = EaConfig(
      magicNumber = 998877L,
      fixedLot = 0.02,
      riskPercent = 1.5,
      stopLossPoints = 300,
      takeProfitPoints = 600
    )
    val script = Mql5CodeGenerator.generateMql5Code(config)
    assertTrue(script.contains("InpMagicNumber          = 998877;"))
    assertTrue(script.contains("OnInit()"))
    assertTrue(script.contains("OnTick()"))
    assertTrue(script.contains("IsDailyDrawdownBreached"))
    assertTrue(script.contains("IsNewsBlackoutActive"))
  }
}

