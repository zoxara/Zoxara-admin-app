package com.example

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.TrendingDown
import androidx.compose.material.icons.automirrored.filled.TrendingUp
import androidx.compose.material.icons.filled.AutoGraph
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.RestartAlt
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.ScrollableTabRow
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.CodeBg
import com.example.ui.theme.GoldDark
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.InfoBlue
import com.example.ui.theme.LossRed
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NeutralMuted
import com.example.ui.theme.NeutralText
import com.example.ui.theme.ObsidianBg
import com.example.ui.theme.ObsidianBorder
import com.example.ui.theme.ObsidianSurface
import com.example.ui.theme.ObsidianSurfaceVariant
import com.example.ui.theme.ProfitGreen

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      MyApplicationTheme(darkTheme = true) {
        GoldEaApp()
      }
    }
  }
}

@Composable
fun GoldEaApp() {
  var selectedTab by remember { mutableIntStateOf(0) }
  var config by remember { mutableStateOf(EaConfig()) }
  val context = LocalContext.current

  val mql5Code = remember(config) {
    Mql5CodeGenerator.generateMql5Code(config)
  }

  fun copyCode() {
    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
    val clip = ClipData.newPlainText("Titan_Gold_EA.mq5", mql5Code)
    clipboard.setPrimaryClip(clip)
    Toast.makeText(context, "Full MQL5 script copied to clipboard!", Toast.LENGTH_SHORT).show()
  }

  fun shareCode() {
    val sendIntent = Intent().apply {
      action = Intent.ACTION_SEND
      putExtra(Intent.EXTRA_TITLE, "Titan_Gold_EA.mq5")
      putExtra(Intent.EXTRA_TEXT, mql5Code)
      type = "text/plain"
    }
    context.startActivity(Intent.createChooser(sendIntent, "Share MQL5 Expert Advisor"))
  }

  Scaffold(
    modifier = Modifier
      .fillMaxSize()
      .testTag("main_scaffold"),
    contentWindowInsets = WindowInsets.safeDrawing,
    containerColor = ObsidianBg
  ) { innerPadding ->
    Column(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding)
    ) {
      // Header Section
      AppHeader(
        onCopy = { copyCode() },
        onShare = { shareCode() }
      )

      // Navigation Tabs
      val tabs = listOf(
        "MQL5 Script" to Icons.Default.Code,
        "EA Settings" to Icons.Default.Tune,
        "Risk Calculator" to Icons.Default.Calculate,
        "MT5 Guide" to Icons.Default.HelpOutline
      )

      ScrollableTabRow(
        selectedTabIndex = selectedTab,
        containerColor = ObsidianSurface,
        contentColor = GoldPrimary,
        edgePadding = 12.dp,
        divider = {
          HorizontalDivider(color = ObsidianBorder, thickness = 1.dp)
        },
        modifier = Modifier.fillMaxWidth().testTag("tabs_row")
      ) {
        tabs.forEachIndexed { index, (title, icon) ->
          Tab(
            selected = selectedTab == index,
            onClick = { selectedTab = index },
            modifier = Modifier.testTag("tab_$index"),
            text = {
              Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                Icon(
                  imageVector = icon,
                  contentDescription = title,
                  modifier = Modifier.size(16.dp),
                  tint = if (selectedTab == index) GoldPrimary else NeutralMuted
                )
                Text(
                  text = title,
                  fontSize = 13.sp,
                  fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                  color = if (selectedTab == index) GoldPrimary else NeutralMuted
                )
              }
            }
          )
        }
      }

      // Tab Content
      Box(
        modifier = Modifier
          .fillMaxSize()
          .weight(1f)
      ) {
        when (selectedTab) {
          0 -> CodeViewerTab(
            code = mql5Code,
            onCopy = { copyCode() },
            onShare = { shareCode() }
          )
          1 -> ConfiguratorTab(
            config = config,
            onConfigChange = { config = it },
            onReset = { config = EaConfig() }
          )
          2 -> RiskCalculatorTab(config = config)
          3 -> Mt5GuideTab()
        }
      }
    }
  }
}

@Composable
fun AppHeader(
  onCopy: () -> Unit,
  onShare: () -> Unit
) {
  Box(
    modifier = Modifier
      .fillMaxWidth()
      .background(
        Brush.verticalGradient(
          colors = listOf(
            Color(0xFF1F1B0E),
            ObsidianSurface
          )
        )
      )
      .padding(horizontal = 16.dp, vertical = 12.dp)
  ) {
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically
    ) {
      Column(modifier = Modifier.weight(1f)) {
        Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Box(
            modifier = Modifier
              .size(8.dp)
              .clip(CircleShape)
              .background(ProfitGreen)
          )
          Text(
            text = "XAUUSD TITAN GOLD EA",
            color = GoldPrimary,
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            letterSpacing = 0.5.sp
          )
        }
        Text(
          text = "MQL5 Algorithmic Trading Bot • MetaTrader 5",
          color = NeutralMuted,
          fontSize = 11.sp,
          fontWeight = FontWeight.Medium
        )
      }

      Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        IconButton(
          onClick = onShare,
          modifier = Modifier
            .size(38.dp)
            .background(ObsidianSurfaceVariant, CircleShape)
            .testTag("header_share_btn")
        ) {
          Icon(
            imageVector = Icons.Default.Share,
            contentDescription = "Share MQL5 Code",
            tint = NeutralText,
            modifier = Modifier.size(18.dp)
          )
        }

        IconButton(
          onClick = onCopy,
          modifier = Modifier
            .size(38.dp)
            .background(GoldPrimary, CircleShape)
            .testTag("header_copy_btn")
        ) {
          Icon(
            imageVector = Icons.Default.ContentCopy,
            contentDescription = "Copy MQL5 Code",
            tint = Color(0xFF1E1602),
            modifier = Modifier.size(18.dp)
          )
        }
      }
    }
  }
}

// -------------------------------------------------------------------------------------------------
// TAB 1: CODE VIEWER
// -------------------------------------------------------------------------------------------------
@Composable
fun CodeViewerTab(
  code: String,
  onCopy: () -> Unit,
  onShare: () -> Unit
) {
  var searchQuery by remember { mutableStateOf("") }
  val lines = remember(code) { code.lines() }
  val filteredIndices = remember(lines, searchQuery) {
    if (searchQuery.isBlank()) emptySet()
    else lines.indices.filter { lines[it].contains(searchQuery, ignoreCase = true) }.toSet()
  }

  Column(modifier = Modifier.fillMaxSize()) {
    // Top Bar with Stats & Search
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .background(ObsidianSurface)
        .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          StatBadge(label = "Lines", value = "${lines.size}")
          StatBadge(label = "Platform", value = "MT5 MQL5")
          StatBadge(label = "Symbol", value = "XAUUSD")
          StatBadge(label = "TF", value = "M5/M15")
        }

        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
          Button(
            onClick = onCopy,
            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.testTag("copy_code_button")
          ) {
            Icon(
              imageVector = Icons.Default.ContentCopy,
              contentDescription = null,
              tint = Color(0xFF1E1602),
              modifier = Modifier.size(14.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
              text = "Copy Script",
              color = Color(0xFF1E1602),
              fontSize = 12.sp,
              fontWeight = FontWeight.Bold
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Filter / Search in code (e.g. OnTick, OnInit, LotSize)", fontSize = 12.sp, color = NeutralMuted) },
        singleLine = true,
        modifier = Modifier
          .fillMaxWidth()
          .testTag("code_search_input"),
        colors = OutlinedTextFieldDefaults.colors(
          focusedContainerColor = ObsidianBg,
          unfocusedContainerColor = ObsidianBg,
          focusedBorderColor = GoldPrimary,
          unfocusedBorderColor = ObsidianBorder,
          focusedTextColor = NeutralText,
          unfocusedTextColor = NeutralText
        ),
        shape = RoundedCornerShape(8.dp)
      )
    }

    // Monospace Code List
    val listState = rememberLazyListState()
    LazyColumn(
      state = listState,
      modifier = Modifier
        .fillMaxSize()
        .background(CodeBg)
        .padding(horizontal = 8.dp)
        .testTag("mql5_code_list")
    ) {
      itemsIndexed(lines) { index, line ->
        val isHighlighted = filteredIndices.contains(index)
        val lineNum = (index + 1).toString().padStart(3, ' ')

        val lineBg = when {
          isHighlighted -> Color(0x33E5B83B)
          index % 2 == 0 -> Color.Transparent
          else -> Color(0x08FFFFFF)
        }

        val textColor = when {
          line.trim().startsWith("//") -> Color(0xFF6B7280) // Grey comment
          line.trim().startsWith("#") -> Color(0xFFEC4899) // Preprocessor pink
          line.trim().startsWith("input") -> Color(0xFFF59E0B) // Input keyword orange
          line.trim().startsWith("group") -> GoldPrimary // Group header gold
          line.contains("OnInit") || line.contains("OnTick") || line.contains("OnDeinit") -> InfoBlue
          line.contains("trade.Buy") || line.contains("trade.Sell") -> ProfitGreen
          else -> Color(0xFFE2E8F0)
        }

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .background(lineBg)
            .padding(vertical = 1.dp)
        ) {
          Text(
            text = lineNum,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = Color(0xFF475569),
            modifier = Modifier.width(36.dp)
          )
          Text(
            text = line,
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            color = textColor,
            modifier = Modifier.weight(1f)
          )
        }
      }
    }
  }
}

@Composable
fun StatBadge(label: String, value: String) {
  Box(
    modifier = Modifier
      .background(ObsidianSurfaceVariant, RoundedCornerShape(6.dp))
      .padding(horizontal = 6.dp, vertical = 2.dp)
  ) {
    Text(
      text = "$label: $value",
      color = NeutralMuted,
      fontSize = 10.sp,
      fontWeight = FontWeight.Medium
    )
  }
}

// -------------------------------------------------------------------------------------------------
// TAB 2: CONFIGURATOR
// -------------------------------------------------------------------------------------------------
@Composable
fun ConfiguratorTab(
  config: EaConfig,
  onConfigChange: (EaConfig) -> Unit,
  onReset: () -> Unit
) {
  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp)
      .testTag("configurator_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header Info Card
    Card(
      colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
      shape = RoundedCornerShape(12.dp),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(GoldPrimary, ObsidianBorder)))
    ) {
      Row(
        modifier = Modifier.padding(16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        Icon(
          imageVector = Icons.Default.Tune,
          contentDescription = null,
          tint = GoldPrimary,
          modifier = Modifier.size(28.dp)
        )
        Column {
          Text(
            text = "Live MQL5 Parameters",
            color = NeutralText,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold
          )
          Text(
            text = "Adjusting these parameters updates the MQL5 script code in real time.",
            color = NeutralMuted,
            fontSize = 12.sp
          )
        }
      }
    }

    // 1. General Settings
    ConfigSectionCard(title = "1. General & Architecture") {
      OutlinedTextField(
        value = config.magicNumber.toString(),
        onValueChange = { input ->
          input.toLongOrNull()?.let { onConfigChange(config.copy(magicNumber = it)) }
        },
        label = { Text("Magic Number (EA Identifier)") },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
        modifier = Modifier.fillMaxWidth().testTag("input_magic_number"),
        colors = outlinedFieldColors()
      )

      Spacer(modifier = Modifier.height(10.dp))

      OutlinedTextField(
        value = config.tradeComment,
        onValueChange = { onConfigChange(config.copy(tradeComment = it)) },
        label = { Text("Trade Order Comment") },
        singleLine = true,
        modifier = Modifier.fillMaxWidth(),
        colors = outlinedFieldColors()
      )

      Spacer(modifier = Modifier.height(10.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Text("Max Allowed Spread: ${config.maxSpreadPoints} points ($${String.format("%.2f", config.maxSpreadPoints * 0.01)})", color = NeutralText, fontSize = 13.sp)
      }
      Slider(
        value = config.maxSpreadPoints.toFloat(),
        onValueChange = { onConfigChange(config.copy(maxSpreadPoints = it.toInt())) },
        valueRange = 10f..100f,
        steps = 9,
        colors = sliderColors()
      )
    }

    // 2. Risk Management
    ConfigSectionCard(title = "2. Risk & Money Management") {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("Auto Risk Mode (% Equity)", color = NeutralText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
          Text("Calculate lot based on account size & SL", color = NeutralMuted, fontSize = 11.sp)
        }
        Switch(
          checked = config.useAutoRisk,
          onCheckedChange = { onConfigChange(config.copy(useAutoRisk = it)) },
          colors = SwitchDefaults.colors(checkedThumbColor = GoldPrimary, checkedTrackColor = GoldDark),
          modifier = Modifier.testTag("switch_auto_risk")
        )
      }

      Spacer(modifier = Modifier.height(12.dp))

      if (!config.useAutoRisk) {
        Text("Fixed Lot Size: ${String.format("%.2f", config.fixedLot)} (Min: 0.01)", color = NeutralText, fontSize = 13.sp)
        Slider(
          value = config.fixedLot.toFloat(),
          onValueChange = { onConfigChange(config.copy(fixedLot = Math.round(it * 100.0) / 100.0)) },
          valueRange = 0.01f..0.20f,
          colors = sliderColors(),
          modifier = Modifier.testTag("slider_fixed_lot")
        )
      } else {
        Text("Risk Per Trade: ${String.format("%.1f", config.riskPercent)}% of Equity", color = NeutralText, fontSize = 13.sp)
        Slider(
          value = config.riskPercent.toFloat(),
          onValueChange = { onConfigChange(config.copy(riskPercent = Math.round(it * 10.0) / 10.0)) },
          valueRange = 0.5f..5.0f,
          colors = sliderColors()
        )
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
        text = "Max Daily Drawdown: ${String.format("%.1f", config.maxDailyDrawdownPercent)}% (Circuit Breaker)",
        color = LossRed,
        fontSize = 13.sp,
        fontWeight = FontWeight.Bold
      )
      Text(
        text = "Halt EA for remainder of day if account equity drops by this threshold",
        color = NeutralMuted,
        fontSize = 11.sp
      )
      Slider(
        value = config.maxDailyDrawdownPercent.toFloat(),
        onValueChange = { onConfigChange(config.copy(maxDailyDrawdownPercent = Math.round(it * 10.0) / 10.0)) },
        valueRange = 1.0f..10.0f,
        colors = SliderDefaults.colors(thumbColor = LossRed, activeTrackColor = LossRed)
      )
    }

    // 3. Technical Strategy Indicators
    ConfigSectionCard(title = "3. Indicator Strategy (EMA + RSI + ATR)") {
      Text("Fast EMA Period: ${config.fastEmaPeriod}", color = NeutralText, fontSize = 13.sp)
      Slider(
        value = config.fastEmaPeriod.toFloat(),
        onValueChange = { onConfigChange(config.copy(fastEmaPeriod = it.toInt())) },
        valueRange = 5f..30f,
        colors = sliderColors()
      )

      Text("Slow EMA Period: ${config.slowEmaPeriod}", color = NeutralText, fontSize = 13.sp)
      Slider(
        value = config.slowEmaPeriod.toFloat(),
        onValueChange = { onConfigChange(config.copy(slowEmaPeriod = it.toInt())) },
        valueRange = 15f..60f,
        colors = sliderColors()
      )

      Text("Trend Filter EMA: ${config.trendEmaPeriod} (Baseline Trend)", color = NeutralText, fontSize = 13.sp)
      Slider(
        value = config.trendEmaPeriod.toFloat(),
        onValueChange = { onConfigChange(config.copy(trendEmaPeriod = it.toInt())) },
        valueRange = 100f..300f,
        steps = 3,
        colors = sliderColors()
      )

      Spacer(modifier = Modifier.height(8.dp))

      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
      ) {
        Text("RSI Period: ${config.rsiPeriod}", color = NeutralText, fontSize = 13.sp)
        Text("Levels: ${config.rsiOversold.toInt()} / ${config.rsiOverbought.toInt()}", color = GoldPrimary, fontSize = 13.sp)
      }
    }

    // 4. Stops & Targets
    ConfigSectionCard(title = "4. Stop Loss & Take Profit (XAUUSD)") {
      Text("Stop Loss: ${config.stopLossPoints} Points ($${String.format("%.2f", config.stopLossPoints * 0.01)} price move)", color = LossRed, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
      Slider(
        value = config.stopLossPoints.toFloat(),
        onValueChange = { onConfigChange(config.copy(stopLossPoints = it.toInt())) },
        valueRange = 100f..800f,
        colors = SliderDefaults.colors(thumbColor = LossRed, activeTrackColor = LossRed),
        modifier = Modifier.testTag("slider_sl_points")
      )

      Text("Take Profit: ${config.takeProfitPoints} Points ($${String.format("%.2f", config.takeProfitPoints * 0.01)} price move)", color = ProfitGreen, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
      Slider(
        value = config.takeProfitPoints.toFloat(),
        onValueChange = { onConfigChange(config.copy(takeProfitPoints = it.toInt())) },
        valueRange = 150f..1500f,
        colors = SliderDefaults.colors(thumbColor = ProfitGreen, activeTrackColor = ProfitGreen)
      )

      val rrRatio = config.takeProfitPoints.toDouble() / config.stopLossPoints.toDouble()
      Text(
        text = "Risk-to-Reward Ratio: 1 : ${String.format("%.2f", rrRatio)}",
        color = if (rrRatio >= 1.5) ProfitGreen else GoldPrimary,
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold
      )
    }

    // 5. Trailing Stop
    ConfigSectionCard(title = "5. Trailing Stop & Profit Lock") {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("Enable Trailing Stop", color = NeutralText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
          Text("Protect profits as gold price moves in favor", color = NeutralMuted, fontSize = 11.sp)
        }
        Switch(
          checked = config.useTrailingStop,
          onCheckedChange = { onConfigChange(config.copy(useTrailingStop = it)) },
          colors = SwitchDefaults.colors(checkedThumbColor = GoldPrimary, checkedTrackColor = GoldDark)
        )
      }

      if (config.useTrailingStop) {
        Spacer(modifier = Modifier.height(10.dp))
        Text("Trailing Activation: ${config.trailingStartPoints} Points ($${String.format("%.2f", config.trailingStartPoints * 0.01)})", color = NeutralText, fontSize = 13.sp)
        Slider(
          value = config.trailingStartPoints.toFloat(),
          onValueChange = { onConfigChange(config.copy(trailingStartPoints = it.toInt())) },
          valueRange = 50f..400f,
          colors = sliderColors()
        )

        Text("Trailing Distance: ${config.trailingStopPoints} Points ($${String.format("%.2f", config.trailingStopPoints * 0.01)})", color = NeutralText, fontSize = 13.sp)
        Slider(
          value = config.trailingStopPoints.toFloat(),
          onValueChange = { onConfigChange(config.copy(trailingStopPoints = it.toInt())) },
          valueRange = 50f..300f,
          colors = sliderColors()
        )
      }
    }

    // 6. News Filter
    ConfigSectionCard(title = "6. High-Impact News Filter") {
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
      ) {
        Column {
          Text("Economic News Blackout", color = NeutralText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
          Text("Pause during CPI, NFP, and FOMC spikes", color = NeutralMuted, fontSize = 11.sp)
        }
        Switch(
          checked = config.enableNewsFilter,
          onCheckedChange = { onConfigChange(config.copy(enableNewsFilter = it)) },
          colors = SwitchDefaults.colors(checkedThumbColor = GoldPrimary, checkedTrackColor = GoldDark)
        )
      }

      if (config.enableNewsFilter) {
        Spacer(modifier = Modifier.height(8.dp))
        Text("Pause Window: ${config.minutesBeforeNews} min before & ${config.minutesAfterNews} min after news event", color = NeutralMuted, fontSize = 12.sp)
      }
    }

    // Reset Button
    OutlinedButton(
      onClick = onReset,
      modifier = Modifier
        .fillMaxWidth()
        .testTag("reset_config_button"),
      colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldPrimary),
      border = ButtonDefaults.outlinedButtonBorder().copy(brush = Brush.horizontalGradient(listOf(GoldPrimary, GoldDark))),
      shape = RoundedCornerShape(10.dp)
    ) {
      Icon(imageVector = Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(16.dp))
      Spacer(modifier = Modifier.width(6.dp))
      Text("Reset to Recommended Gold Defaults")
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}

@Composable
fun ConfigSectionCard(title: String, content: @Composable () -> Unit) {
  Card(
    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
    shape = RoundedCornerShape(12.dp),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(ObsidianBorder, Color(0xFF262E3D)))),
    modifier = Modifier.fillMaxWidth()
  ) {
    Column(modifier = Modifier.padding(16.dp)) {
      Text(
        text = title,
        color = GoldPrimary,
        fontSize = 14.sp,
        fontWeight = FontWeight.Bold
      )
      HorizontalDivider(
        color = ObsidianBorder,
        thickness = 0.5.dp,
        modifier = Modifier.padding(vertical = 10.dp)
      )
      content()
    }
  }
}

// -------------------------------------------------------------------------------------------------
// TAB 3: RISK CALCULATOR
// -------------------------------------------------------------------------------------------------
@Composable
fun RiskCalculatorTab(config: EaConfig) {
  var balanceInput by remember { mutableStateOf("10000") }
  var riskPercentInput by remember { mutableDoubleStateOf(1.0) }
  var slPointsInput by remember { mutableIntStateOf(config.stopLossPoints) }
  var tpPointsInput by remember { mutableIntStateOf(config.takeProfitPoints) }

  val balance = balanceInput.toDoubleOrNull() ?: 10000.0
  val riskAmount = balance * (riskPercentInput / 100.0)

  // In XAUUSD: 1 Standard Lot = 100 oz
  // 1 Point = 0.01 price move ($0.01 per oz).
  // On 1 Standard Lot (100 oz): 1 point = $1.00 USD
  // Therefore, for SL in points: lossPerLot = slPoints * $1.00
  val lossPerStandardLot = slPointsInput * 1.0
  val calculatedLot = if (lossPerStandardLot > 0) riskAmount / lossPerStandardLot else 0.01
  val normalizedLot = Math.max(0.01, Math.floor(calculatedLot * 100.0) / 100.0)

  val rewardAmount = normalizedLot * tpPointsInput * 1.0
  val actualRiskAmount = normalizedLot * slPointsInput * 1.0
  val rrRatio = if (actualRiskAmount > 0) rewardAmount / actualRiskAmount else 2.0

  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp)
      .testTag("risk_calc_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    // Header
    Text(
      text = "Gold (XAUUSD) Position & Risk Sizer",
      color = GoldPrimary,
      fontSize = 18.sp,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = "Standard Contract: 1 Lot = 100 oz • 1 Point = $0.01 • 1 Lot = $1.00/pt",
      color = NeutralMuted,
      fontSize = 12.sp
    )

    // Preset Balance Chips
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .horizontalScroll(rememberScrollState()),
      horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
      listOf("1000", "5000", "10000", "25000", "50000", "100000").forEach { amount ->
        FilterChip(
          selected = balanceInput == amount,
          onClick = { balanceInput = amount },
          label = { Text("$$amount") },
          colors = FilterChipDefaults.filterChipColors(
            selectedContainerColor = GoldDark,
            selectedLabelColor = Color.White,
            containerColor = ObsidianSurface,
            labelColor = NeutralMuted
          )
        )
      }
    }

    // Input Fields Card
    Card(
      colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
      shape = RoundedCornerShape(12.dp),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(ObsidianBorder, Color(0xFF262E3D))))
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(
          value = balanceInput,
          onValueChange = { balanceInput = it },
          label = { Text("Account Balance ($ USD)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
          modifier = Modifier.fillMaxWidth().testTag("calc_balance_input"),
          colors = outlinedFieldColors()
        )

        Column {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Risk per Trade: ${String.format("%.1f", riskPercentInput)}%", color = NeutralText, fontSize = 13.sp)
            Text("$$${String.format("%.2f", riskAmount)}", color = LossRed, fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
          Slider(
            value = riskPercentInput.toFloat(),
            onValueChange = { riskPercentInput = Math.round(it * 10.0) / 10.0 },
            valueRange = 0.5f..5.0f,
            colors = sliderColors()
          )
        }

        Column {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Stop Loss: $slPointsInput Points ($${String.format("%.2f", slPointsInput * 0.01)})", color = LossRed, fontSize = 13.sp)
          }
          Slider(
            value = slPointsInput.toFloat(),
            onValueChange = { slPointsInput = it.toInt() },
            valueRange = 100f..600f,
            colors = SliderDefaults.colors(thumbColor = LossRed, activeTrackColor = LossRed)
          )
        }

        Column {
          Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("Take Profit: $tpPointsInput Points ($${String.format("%.2f", tpPointsInput * 0.01)})", color = ProfitGreen, fontSize = 13.sp)
          }
          Slider(
            value = tpPointsInput.toFloat(),
            onValueChange = { tpPointsInput = it.toInt() },
            valueRange = 200f..1200f,
            colors = SliderDefaults.colors(thumbColor = ProfitGreen, activeTrackColor = ProfitGreen)
          )
        }
      }
    }

    // Results Dashboard Cards
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
      // Lot Size Result
      Card(
        modifier = Modifier.weight(1f),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF162032)),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(GoldPrimary, InfoBlue))),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
          Text("CALCULATED LOT", color = NeutralMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = String.format("%.2f", normalizedLot),
            color = GoldPrimary,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black
          )
          Text("XAUUSD Lots", color = NeutralMuted, fontSize = 11.sp)
        }
      }

      // Risk-Reward Result
      Card(
        modifier = Modifier.weight(1f),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF162032)),
        border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(InfoBlue, ProfitGreen))),
        shape = RoundedCornerShape(12.dp)
      ) {
        Column(modifier = Modifier.padding(14.dp), horizontalAlignment = Alignment.CenterHorizontally) {
          Text("RISK : REWARD", color = NeutralMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
          Spacer(modifier = Modifier.height(4.dp))
          Text(
            text = "1 : ${String.format("%.2f", rrRatio)}",
            color = ProfitGreen,
            fontSize = 24.sp,
            fontWeight = FontWeight.Black
          )
          Text("Expected Edge", color = NeutralMuted, fontSize = 11.sp)
        }
      }
    }

    // Dollar Breakdown Table Card
    Card(
      colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
      shape = RoundedCornerShape(12.dp),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(ObsidianBorder, Color(0xFF262E3D))))
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Order Execution Breakdown", color = GoldPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        HorizontalDivider(color = ObsidianBorder, thickness = 0.5.dp)

        BreakdownRow(label = "Stop Loss Dollar Risk", value = "-$$${String.format("%.2f", actualRiskAmount)}", color = LossRed)
        BreakdownRow(label = "Take Profit Dollar Reward", value = "+$$${String.format("%.2f", rewardAmount)}", color = ProfitGreen)
        BreakdownRow(label = "Pip / Point Value", value = "$$${String.format("%.2f", normalizedLot * 1.0)} / pt", color = NeutralText)
        BreakdownRow(label = "Max Daily Loss Limit (3%)", value = "-$$${String.format("%.2f", balance * 0.03)}", color = LossRed)
      }
    }

    // Strategy Blueprint Checklist
    Card(
      colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
      shape = RoundedCornerShape(12.dp),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(ObsidianBorder, Color(0xFF262E3D))))
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("XAUUSD Strategy Architecture", color = GoldPrimary, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        StrategyStepItem(
          title = "1. Trend Confirmation",
          desc = "Price and Fast/Slow EMAs must be ABOVE 200 EMA for Buys, or BELOW for Sells."
        )
        StrategyStepItem(
          title = "2. Momentum Trigger",
          desc = "Fast 9 EMA crosses Slow 21 EMA on the closed candle to prevent repainting."
        )
        StrategyStepItem(
          title = "3. RSI Exhaustion Filter",
          desc = "RSI must be between 50-70 for Buys (healthy momentum, avoiding overbought tops)."
        )
        StrategyStepItem(
          title = "4. Daily Drawdown Guard",
          desc = "If current equity drops by Max Daily % from 00:00 server time, trading stops immediately."
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}

@Composable
fun BreakdownRow(label: String, value: String, color: Color) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically
  ) {
    Text(label, color = NeutralMuted, fontSize = 13.sp)
    Text(value, color = color, fontSize = 13.sp, fontWeight = FontWeight.Bold)
  }
}

@Composable
fun StrategyStepItem(title: String, desc: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.spacedBy(8.dp),
    verticalAlignment = Alignment.Top
  ) {
    Icon(
      imageVector = Icons.Default.CheckCircle,
      contentDescription = null,
      tint = ProfitGreen,
      modifier = Modifier.size(16.dp).padding(top = 2.dp)
    )
    Column {
      Text(title, color = NeutralText, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
      Text(desc, color = NeutralMuted, fontSize = 11.sp)
    }
  }
}

// -------------------------------------------------------------------------------------------------
// TAB 4: MT5 GUIDE
// -------------------------------------------------------------------------------------------------
@Composable
fun Mt5GuideTab() {
  val scrollState = rememberScrollState()

  Column(
    modifier = Modifier
      .fillMaxSize()
      .verticalScroll(scrollState)
      .padding(16.dp)
      .testTag("guide_screen"),
    verticalArrangement = Arrangement.spacedBy(16.dp)
  ) {
    Text(
      text = "How to Install & Attach to MT5",
      color = GoldPrimary,
      fontSize = 18.sp,
      fontWeight = FontWeight.Bold
    )
    Text(
      text = "Follow these 5 steps to compile and run Titan Gold EA on MetaTrader 5.",
      color = NeutralMuted,
      fontSize = 12.sp
    )

    GuideStepCard(
      stepNum = 1,
      title = "Open MetaEditor in MT5",
      desc = "Launch MetaTrader 5 on your PC/VPS. Press F4 on your keyboard, or navigate to Tools -> MetaQuotes Language Editor.",
      tip = "Shortcut: F4"
    )

    GuideStepCard(
      stepNum = 2,
      title = "Create New Expert Advisor File",
      desc = "In MetaEditor, click File -> New -> Expert Advisor (template). Name the file 'Titan_Gold_EA' and click Next until finished.",
      tip = "Saves in: MQL5/Experts/Titan_Gold_EA.mq5"
    )

    GuideStepCard(
      stepNum = 3,
      title = "Paste Code & Compile (F7)",
      desc = "Select all existing template text (Ctrl+A) and delete it. Paste the complete MQL5 source code from this app. Click the green 'Compile' button or press F7.",
      tip = "Verify: 0 errors, 0 warnings in the MetaEditor toolbox."
    )

    GuideStepCard(
      stepNum = 4,
      title = "Attach to XAUUSD Chart",
      desc = "Return to MT5 (F4). In the Navigator window (Ctrl+N), expand 'Expert Advisors' -> find 'Titan_Gold_EA'. Drag and drop it onto an open XAUUSD chart set to M5 or M15 timeframe.",
      tip = "Recommended Timeframe: M5 or M15"
    )

    GuideStepCard(
      stepNum = 5,
      title = "Allow Algorithmic Trading",
      desc = "In the EA settings popup, switch to the 'Common' tab and check 'Allow Algo Trading'. Finally, click the 'Algo Trading' button in the top MT5 toolbar to turn it green.",
      tip = "A small blue hat/grad cap icon should appear in the top-right corner of the chart."
    )

    // Recommended Environment Card
    Card(
      colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
      shape = RoundedCornerShape(12.dp),
      border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(GoldPrimary, ObsidianBorder)))
    ) {
      Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          Icon(Icons.Default.Info, contentDescription = null, tint = InfoBlue, modifier = Modifier.size(20.dp))
          Text("Gold Trading Best Practices", color = NeutralText, fontSize = 14.sp, fontWeight = FontWeight.Bold)
        }
        Text(
          text = "• Broker Spread: Ensure your broker offers Raw Spread / ECN accounts where Gold spread is under 25-30 points ($0.25-$0.30).\n" +
                 "• Low Latency VPS: Run the bot on a London or New York VPS (under 5ms latency) for optimal slippage protection.\n" +
                 "• Contract Check: Most brokers use 100 oz per standard lot. If your broker uses 10 oz (mini gold), the lot calculator will auto-scale via MarketInfo tick value.",
          color = NeutralMuted,
          fontSize = 12.sp,
          lineHeight = 18.sp
        )
      }
    }

    Spacer(modifier = Modifier.height(24.dp))
  }
}

@Composable
fun GuideStepCard(
  stepNum: Int,
  title: String,
  desc: String,
  tip: String
) {
  Card(
    colors = CardDefaults.cardColors(containerColor = ObsidianSurface),
    shape = RoundedCornerShape(12.dp),
    border = CardDefaults.outlinedCardBorder().copy(brush = Brush.horizontalGradient(listOf(ObsidianBorder, Color(0xFF262E3D)))),
    modifier = Modifier.fillMaxWidth()
  ) {
    Row(
      modifier = Modifier.padding(16.dp),
      horizontalArrangement = Arrangement.spacedBy(14.dp),
      verticalAlignment = Alignment.Top
    ) {
      Box(
        modifier = Modifier
          .size(32.dp)
          .background(GoldPrimary, CircleShape),
        contentAlignment = Alignment.Center
      ) {
        Text(
          text = "$stepNum",
          color = Color(0xFF1E1602),
          fontWeight = FontWeight.Black,
          fontSize = 15.sp
        )
      }

      Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(title, color = NeutralText, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Text(desc, color = NeutralMuted, fontSize = 12.sp, lineHeight = 17.sp)
        Box(
          modifier = Modifier
            .background(ObsidianSurfaceVariant, RoundedCornerShape(6.dp))
            .padding(horizontal = 8.dp, vertical = 4.dp)
        ) {
          Text(tip, color = GoldLight, fontSize = 11.sp, fontFamily = FontFamily.Monospace)
        }
      }
    }
  }
}

// -------------------------------------------------------------------------------------------------
// Helpers
// -------------------------------------------------------------------------------------------------
@Composable
fun outlinedFieldColors() = OutlinedTextFieldDefaults.colors(
  focusedContainerColor = ObsidianBg,
  unfocusedContainerColor = ObsidianBg,
  focusedBorderColor = GoldPrimary,
  unfocusedBorderColor = ObsidianBorder,
  focusedLabelColor = GoldPrimary,
  unfocusedLabelColor = NeutralMuted,
  focusedTextColor = NeutralText,
  unfocusedTextColor = NeutralText
)

@Composable
fun sliderColors() = SliderDefaults.colors(
  thumbColor = GoldPrimary,
  activeTrackColor = GoldPrimary,
  inactiveTrackColor = ObsidianBorder
)

@Preview(showBackground = true)
@Composable
fun GoldEaAppPreview() {
  MyApplicationTheme(darkTheme = true) {
    GoldEaApp()
  }
}

@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

