package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val GoldPrimary = Color(0xFFE5B83B)
val GoldLight = Color(0xFFFDE047)
val GoldDark = Color(0xFFB48316)
val GoldGlow = Color(0x33E5B83B)

val ObsidianBg = Color(0xFF090D16)
val ObsidianSurface = Color(0xFF111827)
val ObsidianSurfaceVariant = Color(0xFF1F2937)
val ObsidianBorder = Color(0xFF374151)

val ProfitGreen = Color(0xFF10B981)
val LossRed = Color(0xFFEF4444)
val InfoBlue = Color(0xFF38BDF8)
val NeutralText = Color(0xFFF3F4F6)
val NeutralMuted = Color(0xFF9CA3AF)
val CodeBg = Color(0xFF070A10)

