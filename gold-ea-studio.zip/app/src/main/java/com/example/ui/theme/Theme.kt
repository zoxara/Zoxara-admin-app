package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme =
  darkColorScheme(
    primary = GoldPrimary,
    onPrimary = Color(0xFF1E1602),
    primaryContainer = GoldDark,
    onPrimaryContainer = GoldLight,
    secondary = InfoBlue,
    onSecondary = Color(0xFF00354E),
    tertiary = ProfitGreen,
    background = ObsidianBg,
    onBackground = NeutralText,
    surface = ObsidianSurface,
    onSurface = NeutralText,
    surfaceVariant = ObsidianSurfaceVariant,
    onSurfaceVariant = NeutralMuted,
    outline = ObsidianBorder,
    error = LossRed,
  )

private val LightColorScheme =
  lightColorScheme(
    primary = GoldDark,
    onPrimary = Color.White,
    primaryContainer = Color(0xFFFEF08A),
    onPrimaryContainer = Color(0xFF713F12),
    secondary = Color(0xFF0284C7),
    onSecondary = Color.White,
    tertiary = Color(0xFF059669),
    background = Color(0xFFF8FAFC),
    onBackground = Color(0xFF0F172A),
    surface = Color.White,
    onSurface = Color(0xFF0F172A),
    surfaceVariant = Color(0xFFF1F5F9),
    onSurfaceVariant = Color(0xFF64748B),
    outline = Color(0xFFCBD5E1),
    error = LossRed,
  )

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = true,
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

  MaterialTheme(colorScheme = colorScheme, typography = Typography, content = content)
}

