package com.example

data class EaConfig(
  val magicNumber: Long = 777108L,
  val tradeComment: String = "Titan_Gold_EA",
  val useAutoRisk: Boolean = false,
  val fixedLot: Double = 0.01,
  val riskPercent: Double = 1.0,
  val maxDailyDrawdownPercent: Double = 3.0,
  val maxSpreadPoints: Int = 45,
  val fastEmaPeriod: Int = 9,
  val slowEmaPeriod: Int = 21,
  val trendEmaPeriod: Int = 200,
  val rsiPeriod: Int = 14,
  val rsiOverbought: Double = 70.0,
  val rsiOversold: Double = 30.0,
  val atrPeriod: Int = 14,
  val stopLossPoints: Int = 250,
  val takeProfitPoints: Int = 500,
  val useTrailingStop: Boolean = true,
  val trailingStartPoints: Int = 150,
  val trailingStopPoints: Int = 100,
  val trailingStepPoints: Int = 20,
  val enableNewsFilter: Boolean = true,
  val minutesBeforeNews: Int = 30,
  val minutesAfterNews: Int = 30
)

object Mql5CodeGenerator {

  fun generateMql5Code(config: EaConfig): String {
    val autoRiskStr = if (config.useAutoRisk) "true" else "false"
    val trailingStr = if (config.useTrailingStop) "true" else "false"
    val newsStr = if (config.enableNewsFilter) "true" else "false"

    return """
//+------------------------------------------------------------------+
//|                                              Titan_Gold_EA.mq5   |
//|                             Algorithmic Trading Bot for XAUUSD   |
//|                                  Platform: MetaTrader 5 (MQL5)   |
//+------------------------------------------------------------------+
#property copyright "Titan Algorithmic Trading Systems"
#property link      "https://ai.studio"
#property version   "1.00"
#property description "Professional Algorithmic Expert Advisor for XAUUSD (Gold)"
#property description "Combines EMA Multi-Timeframe Trend, Momentum Cross, RSI & ATR Volatility"
#property description "Includes Daily Drawdown Guard, Trailing Stop, and News Blackout Protection"

//--- Include Standard MQL5 Trade Classes
#include <Trade\Trade.mqh>
#include <Trade\PositionInfo.mqh>
#include <Trade\AccountInfo.mqh>
#include <Trade\SymbolInfo.mqh>

//+------------------------------------------------------------------+
//|                       INPUT PARAMETERS                           |
//+------------------------------------------------------------------+
group "=== 1. General & System Settings ==="
input ulong             InpMagicNumber          = ${config.magicNumber};         // Magic Identifier Number
input string            InpTradeComment         = "${config.tradeComment}"; // Trade Order Comment
input int               InpMaxSpreadPoints      = ${config.maxSpreadPoints};             // Max Allowed Spread (Points)
input int               InpSlippagePoints       = 30;             // Max Order Slippage (Points)

group "=== 2. Risk & Money Management ==="
input bool              InpUseAutoRisk          = $autoRiskStr;          // Use % Equity Risk (false = Fixed Lot)
input double            InpFixedLot             = ${String.format("%.2f", config.fixedLot)};           // Fixed Order Lot Size (Min 0.01)
input double            InpRiskPercent          = ${String.format("%.1f", config.riskPercent)};            // Risk % Per Trade (if AutoRisk is true)
input double            InpMaxDailyDrawdown     = ${String.format("%.1f", config.maxDailyDrawdownPercent)};            // Max Daily Loss % (Circuit Breaker)
input int               InpMaxOpenPositions     = 1;              // Max Allowed Open Positions (1 = Conservative)

group "=== 3. Technical Indicator Strategy ==="
input int               InpFastEmaPeriod        = ${config.fastEmaPeriod};              // Fast EMA Period (Signal Trigger)
input int               InpSlowEmaPeriod        = ${config.slowEmaPeriod};             // Slow EMA Period (Signal Base)
input int               InpTrendEmaPeriod       = ${config.trendEmaPeriod};            // Trend Baseline EMA (200 = Major Trend)
input int               InpRsiPeriod            = ${config.rsiPeriod};             // RSI Period
input double            InpRsiOverbought        = ${String.format("%.1f", config.rsiOverbought)};           // RSI Overbought Level (No Longs above)
input double            InpRsiOversold          = ${String.format("%.1f", config.rsiOversold)};           // RSI Oversold Level (No Shorts below)
input int               InpAtrPeriod            = ${config.atrPeriod};             // ATR Volatility Period

group "=== 4. Stop Loss & Take Profit ==="
input int               InpStopLossPoints       = ${config.stopLossPoints};            // Stop Loss in Points (250 pts = $2.50)
input int               InpTakeProfitPoints     = ${config.takeProfitPoints};            // Take Profit in Points (500 pts = $5.00)

group "=== 5. Trailing Stop & Profit Lock ==="
input bool              InpUseTrailingStop      = $trailingStr;           // Enable Trailing Stop
input int               InpTrailingStartPoints  = ${config.trailingStartPoints};            // Trailing Activation Profit (Points)
input int               InpTrailingStopPoints   = ${config.trailingStopPoints};            // Distance Behind Price (Points)
input int               InpTrailingStepPoints   = ${config.trailingStepPoints};             // Step Increment (Points)

group "=== 6. News & Volatility Filter ==="
input bool              InpEnableNewsFilter     = $newsStr;           // Enable High-Impact News Blackout
input int               InpMinutesBeforeNews    = ${config.minutesBeforeNews};             // Minutes to Pause BEFORE News
input int               InpMinutesAfterNews     = ${config.minutesAfterNews};             // Minutes to Pause AFTER News
input bool              InpBlockUsSessionNews   = true;           // Pause during US High-Impact Time (12:30-15:30 GMT)

//+------------------------------------------------------------------+
//|                      GLOBAL VARIABLES & HANDLES                  |
//+------------------------------------------------------------------+
CTrade         trade;
CPositionInfo  positionInfo;
CAccountInfo   accountInfo;
CSymbolInfo    symbolInfo;

int            hFastEma     = INVALID_HANDLE;
int            hSlowEma     = INVALID_HANDLE;
int            hTrendEma    = INVALID_HANDLE;
int            hRsi         = INVALID_HANDLE;
int            hAtr         = INVALID_HANDLE;

datetime       lastBarTime  = 0;
double         dailyStartEquity = 0.0;
int            currentDayOfYear = -1;
bool           dailyLimitTripped = false;

//+------------------------------------------------------------------+
//| Expert initialization function                                   |
//+------------------------------------------------------------------+
int OnInit()
{
   // 1. Symbol & Market Setup
   if(!symbolInfo.Name(_Symbol))
   {
      Print("[-] Error: Unable to initialize symbol: ", _Symbol);
      return(INIT_FAILED);
   }
   symbolInfo.Refresh();

   // 2. Set Trade Management Credentials
   trade.SetExpertMagicNumber(InpMagicNumber);
   trade.SetDeviationInPoints(InpSlippagePoints);
   trade.SetTypeFillingBySymbol(_Symbol);

   // 3. Initialize Starting Equity for Daily Loss Protection
   dailyStartEquity = accountInfo.Equity();
   MqlDateTime dt;
   TimeCurrent(dt);
   currentDayOfYear = dt.day_of_year;
   dailyLimitTripped = false;

   // 4. Create Indicator Handles
   hFastEma = iMA(_Symbol, _Period, InpFastEmaPeriod, 0, MODE_EMA, PRICE_CLOSE);
   hSlowEma = iMA(_Symbol, _Period, InpSlowEmaPeriod, 0, MODE_EMA, PRICE_CLOSE);
   hTrendEma = iMA(_Symbol, _Period, InpTrendEmaPeriod, 0, MODE_EMA, PRICE_CLOSE);
   hRsi     = iRSI(_Symbol, _Period, InpRsiPeriod, PRICE_CLOSE);
   hAtr     = iATR(_Symbol, _Period, InpAtrPeriod);

   if(hFastEma == INVALID_HANDLE || hSlowEma == INVALID_HANDLE || 
      hTrendEma == INVALID_HANDLE || hRsi == INVALID_HANDLE || hAtr == INVALID_HANDLE)
   {
      Print("[-] Error creating technical indicator handles. Error code: ", GetLastError());
      return(INIT_FAILED);
   }

   Print("[+] Titan Gold EA Initialized Successfully on ", _Symbol, " Timeframe: ", EnumToString(_Period));
   Print("[+] Daily Starting Equity set to: $", DoubleToString(dailyStartEquity, 2));
   
   UpdateChartDashboard("INITIALIZED - WAITING FOR SIGNALS", 0.0, 0);
   return(INIT_SUCCEEDED);
}

//+------------------------------------------------------------------+
//| Expert deinitialization function                                 |
//+------------------------------------------------------------------+
void OnDeinit(const int reason)
{
   // Release technical indicator resources
   if(hFastEma != INVALID_HANDLE)  IndicatorRelease(hFastEma);
   if(hSlowEma != INVALID_HANDLE)  IndicatorRelease(hSlowEma);
   if(hTrendEma != INVALID_HANDLE) IndicatorRelease(hTrendEma);
   if(hRsi != INVALID_HANDLE)      IndicatorRelease(hRsi);
   if(hAtr != INVALID_HANDLE)      IndicatorRelease(hAtr);

   Comment(""); // Clear chart dashboard
   Print("[*] Titan Gold EA Deinitialized. Reason code: ", reason);
}

//+------------------------------------------------------------------+
//| Expert tick function                                             |
//+------------------------------------------------------------------+
void OnTick()
{
   // Refresh Market Data
   if(!symbolInfo.RefreshRates()) return;

   // 1. Maintain Daily Start Equity Tracking
   CheckAndResetDailyEquity();

   // 2. Risk Check: Max Daily Drawdown Protection
   if(IsDailyDrawdownBreached())
   {
      UpdateChartDashboard("HALTED: DAILY DRAWDOWN LIMIT HIT", GetCurrentDailyDrawdown(), CountOpenPositions());
      return;
   }

   // 3. Trailing Stop Management (Always active on every tick for protection)
   if(InpUseTrailingStop)
   {
      ManageTrailingStop();
   }

   // 4. Bar Open Check (Strategy calculates on bar close to eliminate repainting)
   if(!IsNewBar())
   {
      return;
   }

   // 5. Spread Filter
   long currentSpread = symbolInfo.Spread();
   if(currentSpread > InpMaxSpreadPoints)
   {
      Print("[!] High Spread detected: ", currentSpread, " pts (Max: ", InpMaxSpreadPoints, "). Skipping signal.");
      UpdateChartDashboard("PAUSED: SPREAD TOO HIGH", GetCurrentDailyDrawdown(), CountOpenPositions());
      return;
   }

   // 6. News & Economic Filter Check
   if(InpEnableNewsFilter && IsNewsBlackoutActive())
   {
      Print("[!] News Blackout active. Trading paused to prevent slippage.");
      UpdateChartDashboard("PAUSED: HIGH IMPACT NEWS BLACKOUT", GetCurrentDailyDrawdown(), CountOpenPositions());
      return;
   }

   // 7. Max Open Positions Check
   int openCount = CountOpenPositions();
   if(openCount >= InpMaxOpenPositions)
   {
      UpdateChartDashboard("POSITION ACTIVE", GetCurrentDailyDrawdown(), openCount);
      return;
   }

   // 8. Indicator Signal Evaluation
   int signal = EvaluateStrategySignals();

   // 9. Order Execution
   if(signal == 1) // BUY Signal
   {
      ExecuteBuyOrder();
   }
   else if(signal == -1) // SELL Signal
   {
      ExecuteSellOrder();
   }
   else
   {
      UpdateChartDashboard("SCANNING FOR GOLD OPPORTUNITY", GetCurrentDailyDrawdown(), openCount);
   }
}

//+------------------------------------------------------------------+
//| Check if a new candle bar has formed                             |
//+------------------------------------------------------------------+
bool IsNewBar()
{
   datetime currentBarTime = iTime(_Symbol, _Period, 0);
   if(currentBarTime != lastBarTime)
   {
      lastBarTime = currentBarTime;
      return true;
   }
   return false;
}

//+------------------------------------------------------------------+
//| Reset Daily Baseline at 00:00 Server Time                        |
//+------------------------------------------------------------------+
void CheckAndResetDailyEquity()
{
   MqlDateTime dt;
   TimeCurrent(dt);

   if(dt.day_of_year != currentDayOfYear)
   {
      currentDayOfYear = dt.day_of_year;
      dailyStartEquity = accountInfo.Equity();
      dailyLimitTripped = false;
      Print("[*] New Trading Day Detected. Reset Daily Starting Equity: $", DoubleToString(dailyStartEquity, 2));
   }
}

//+------------------------------------------------------------------+
//| Check if Account Drawdown Exceeds Daily Limit                    |
//+------------------------------------------------------------------+
bool IsDailyDrawdownBreached()
{
   if(dailyLimitTripped) return true;
   if(dailyStartEquity <= 0.0) return false;

   double currentEquity = accountInfo.Equity();
   double drop = dailyStartEquity - currentEquity;

   if(drop > 0)
   {
      double dropPercent = (drop / dailyStartEquity) * 100.0;
      if(dropPercent >= InpMaxDailyDrawdown)
      {
         dailyLimitTripped = true;
         Print("[-] EMERGENCY: Max Daily Drawdown Breached! Drop: ", DoubleToString(dropPercent, 2), 
               "% (Max Allowed: ", DoubleToString(InpMaxDailyDrawdown, 2), "%). EA Trading Halted.");
         return true;
      }
   }
   return false;
}

//+------------------------------------------------------------------+
//| Get Current Daily Drawdown Percentage                            |
//+------------------------------------------------------------------+
double GetCurrentDailyDrawdown()
{
   if(dailyStartEquity <= 0.0) return 0.0;
   double currentEquity = accountInfo.Equity();
   if(currentEquity >= dailyStartEquity) return 0.0;
   return ((dailyStartEquity - currentEquity) / dailyStartEquity) * 100.0;
}

//+------------------------------------------------------------------+
//| Built-in News Filter Check (Time-Based + Economic Calendar Stub) |
//+------------------------------------------------------------------+
bool IsNewsBlackoutActive()
{
   // 1. Time-window guard around major US Economic Data (CPI, NFP, FOMC)
   // Typically released at 12:30 or 14:00 GMT
   if(InpBlockUsSessionNews)
   {
      MqlDateTime dt;
      TimeGMT(dt);
      
      // Blackout high impact window: 12:15 to 14:45 GMT on Wednesday, Thursday, Friday
      if(dt.day_of_week >= 3 && dt.day_of_week <= 5)
      {
         int minuteOfDay = dt.hour * 60 + dt.min;
         int newsWindowStart = 12 * 60 + 15; // 12:15 GMT
         int newsWindowEnd   = 14 * 60 + 45; // 14:45 GMT
         
         if(minuteOfDay >= newsWindowStart && minuteOfDay <= newsWindowEnd)
         {
            return true;
         }
      }
   }

   // 2. MT5 Built-in Economic Calendar Integration
   // Ready for brokers supporting MQL5 CalendarValueHistory API
   return false;
}

//+------------------------------------------------------------------+
//| Core Technical Strategy: EMA Cross + 200 EMA + RSI + ATR         |
//+------------------------------------------------------------------+
int EvaluateStrategySignals()
{
   // Buffers for 2 completed bars (Bar 1 and Bar 2)
   double fastEma[2], slowEma[2], trendEma[2], rsi[2], atr[2];

   if(CopyBuffer(hFastEma, 0, 1, 2, fastEma) < 2) return 0;
   if(CopyBuffer(hSlowEma, 0, 1, 2, slowEma) < 2) return 0;
   if(CopyBuffer(hTrendEma, 0, 1, 2, trendEma) < 2) return 0;
   if(CopyBuffer(hRsi, 0, 1, 2, rsi) < 2) return 0;
   if(CopyBuffer(hAtr, 0, 1, 2, atr) < 2) return 0;

   // Index 1 = Closed Bar 1, Index 0 = Closed Bar 2
   double fast1 = fastEma[1], fast2 = fastEma[0];
   double slow1 = slowEma[1], slow2 = slowEma[0];
   double trend1 = trendEma[1];
   double rsiVal = rsi[1];
   double closePrice1 = iClose(_Symbol, _Period, 1);

   // Bullish Signal Conditions:
   // 1. Fast EMA crosses ABOVE Slow EMA (Golden Cross on Bar 1 vs Bar 2)
   // 2. Price and EMAs are ABOVE 200 Trend EMA (Confirms Macro Uptrend)
   // 3. RSI is between 50 and 70 (Healthy upward momentum without overbought exhaustion)
   bool buyCross = (fast2 <= slow2) && (fast1 > slow1);
   bool buyTrend = (closePrice1 > trend1) && (fast1 > trend1);
   bool buyRsi   = (rsiVal >= 50.0 && rsiVal < InpRsiOverbought);

   if(buyCross && buyTrend && buyRsi)
   {
      Print("[+] Strong BUY Signal: FastEMA crossed SlowEMA above 200 EMA. RSI: ", DoubleToString(rsiVal, 1));
      return 1;
   }

   // Bearish Signal Conditions:
   // 1. Fast EMA crosses BELOW Slow EMA (Death Cross on Bar 1 vs Bar 2)
   // 2. Price and EMAs are BELOW 200 Trend EMA (Confirms Macro Downtrend)
   // 3. RSI is between 30 and 50 (Healthy downward momentum without oversold exhaustion)
   bool sellCross = (fast2 >= slow2) && (fast1 < slow1);
   bool sellTrend = (closePrice1 < trend1) && (fast1 < trend1);
   bool sellRsi   = (rsiVal <= 50.0 && rsiVal > InpRsiOversold);

   if(sellCross && sellTrend && sellRsi)
   {
      Print("[-] Strong SELL Signal: FastEMA crossed SlowEMA below 200 EMA. RSI: ", DoubleToString(rsiVal, 1));
      return -1;
   }

   return 0; // No valid trigger
}

//+------------------------------------------------------------------+
//| Calculate Normalized Lot Size for XAUUSD                         |
//+------------------------------------------------------------------+
double CalculateLotSize(double slPoints)
{
   if(!InpUseAutoRisk)
   {
      return NormalizeLotSize(InpFixedLot);
   }

   double equity = accountInfo.Equity();
   double riskAmount = equity * (InpRiskPercent / 100.0);
   double tickValue = symbolInfo.TickValue();
   double tickSize = symbolInfo.TickSize();
   double point = symbolInfo.Point();

   if(tickSize <= 0 || point <= 0 || tickValue <= 0 || slPoints <= 0)
   {
      return NormalizeLotSize(InpFixedLot);
   }

   double pointsToTicks = slPoints * (point / tickSize);
   double lossPerLot = pointsToTicks * tickValue;

   if(lossPerLot <= 0) return NormalizeLotSize(InpFixedLot);

   double computedLot = riskAmount / lossPerLot;
   return NormalizeLotSize(computedLot);
}

//+------------------------------------------------------------------+
//| Clamps lot size within broker limits                             |
//+------------------------------------------------------------------+
double NormalizeLotSize(double rawLot)
{
   double minLot = symbolInfo.LotsMin();
   double maxLot = symbolInfo.LotsMax();
   double step   = symbolInfo.LotsStep();

   if(step <= 0) step = 0.01;
   double lot = MathFloor(rawLot / step) * step;

   if(lot < minLot) lot = minLot;
   if(lot > maxLot) lot = maxLot;

   int digits = (step == 0.01) ? 2 : (step == 0.1 ? 1 : 0);
   return NormalizeDouble(lot, digits);
}

//+------------------------------------------------------------------+
//| Execute BUY Order with SL & TP                                   |
//+------------------------------------------------------------------+
void ExecuteBuyOrder()
{
   double ask = symbolInfo.Ask();
   double point = symbolInfo.Point();
   double slPrice = (InpStopLossPoints > 0)   ? (ask - InpStopLossPoints * point)   : 0.0;
   double tpPrice = (InpTakeProfitPoints > 0) ? (ask + InpTakeProfitPoints * point) : 0.0;

   slPrice = NormalizeDouble(slPrice, _Digits);
   tpPrice = NormalizeDouble(tpPrice, _Digits);

   double lotSize = CalculateLotSize(InpStopLossPoints);

   if(trade.Buy(lotSize, _Symbol, ask, slPrice, tpPrice, InpTradeComment))
   {
      Print("[+] BUY Executed: ", lotSize, " Lots @ ", ask, " SL: ", slPrice, " TP: ", tpPrice);
   }
   else
   {
      Print("[-] BUY Order Failed! Error: ", trade.ResultRetcode(), " - ", trade.ResultRetcodeDescription());
   }
}

//+------------------------------------------------------------------+
//| Execute SELL Order with SL & TP                                  |
//+------------------------------------------------------------------+
void ExecuteSellOrder()
{
   double bid = symbolInfo.Bid();
   double point = symbolInfo.Point();
   double slPrice = (InpStopLossPoints > 0)   ? (bid + InpStopLossPoints * point)   : 0.0;
   double tpPrice = (InpTakeProfitPoints > 0) ? (bid - InpTakeProfitPoints * point) : 0.0;

   slPrice = NormalizeDouble(slPrice, _Digits);
   tpPrice = NormalizeDouble(tpPrice, _Digits);

   double lotSize = CalculateLotSize(InpStopLossPoints);

   if(trade.Sell(lotSize, _Symbol, bid, slPrice, tpPrice, InpTradeComment))
   {
      Print("[+] SELL Executed: ", lotSize, " Lots @ ", bid, " SL: ", slPrice, " TP: ", tpPrice);
   }
   else
   {
      Print("[-] SELL Order Failed! Error: ", trade.ResultRetcode(), " - ", trade.ResultRetcodeDescription());
   }
}

//+------------------------------------------------------------------+
//| Trailing Stop Logic                                              |
//+------------------------------------------------------------------+
void ManageTrailingStop()
{
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      if(!positionInfo.SelectByIndex(i)) continue;
      if(positionInfo.Symbol() != _Symbol) continue;
      if(positionInfo.Magic() != InpMagicNumber) continue;

      double point = symbolInfo.Point();
      double currentPrice = (positionInfo.PositionType() == POSITION_TYPE_BUY) ? symbolInfo.Bid() : symbolInfo.Ask();
      double openPrice    = positionInfo.PriceOpen();
      double currentSL    = positionInfo.StopLoss();

      if(positionInfo.PositionType() == POSITION_TYPE_BUY)
      {
         double profitPoints = (currentPrice - openPrice) / point;
         if(profitPoints >= InpTrailingStartPoints)
         {
            double newSL = NormalizeDouble(currentPrice - InpTrailingStopPoints * point, _Digits);
            if(newSL > currentSL + InpTrailingStepPoints * point)
            {
               trade.PositionModify(positionInfo.Ticket(), newSL, positionInfo.TakeProfit());
               Print("[*] Trailing Stop Adjusted for BUY #", positionInfo.Ticket(), " -> New SL: ", newSL);
            }
         }
      }
      else if(positionInfo.PositionType() == POSITION_TYPE_SELL)
      {
         double profitPoints = (openPrice - currentPrice) / point;
         if(profitPoints >= InpTrailingStartPoints)
         {
            double newSL = NormalizeDouble(currentPrice + InpTrailingStopPoints * point, _Digits);
            if(currentSL == 0.0 || newSL < currentSL - InpTrailingStepPoints * point)
            {
               trade.PositionModify(positionInfo.Ticket(), newSL, positionInfo.TakeProfit());
               Print("[*] Trailing Stop Adjusted for SELL #", positionInfo.Ticket(), " -> New SL: ", newSL);
            }
         }
      }
   }
}

//+------------------------------------------------------------------+
//| Count Open Positions matching Symbol and Magic Number            |
//+------------------------------------------------------------------+
int CountOpenPositions()
{
   int count = 0;
   for(int i = PositionsTotal() - 1; i >= 0; i--)
   {
      if(positionInfo.SelectByIndex(i))
      {
         if(positionInfo.Symbol() == _Symbol && positionInfo.Magic() == InpMagicNumber)
         {
            count++;
         }
      }
   }
   return count;
}

//+------------------------------------------------------------------+
//| Display Live Professional Status Dashboard on Chart              |
//+------------------------------------------------------------------+
void UpdateChartDashboard(string status, double drawdown, int openTrades)
{
   string text = "";
   text += "========================================\n";
   text += "       TITAN XAUUSD EXPERT ADVISOR      \n";
   text += "========================================\n";
   text += " Symbol:        " + _Symbol + " (" + EnumToString(_Period) + ")\n";
   text += " EA Status:     " + status + "\n";
   text += " Account Eq:    $" + DoubleToString(accountInfo.Equity(), 2) + "\n";
   text += " Daily Start:   $" + DoubleToString(dailyStartEquity, 2) + "\n";
   text += " Daily Loss %:  " + DoubleToString(drawdown, 2) + "% / " + DoubleToString(InpMaxDailyDrawdown, 2) + "%\n";
   text += " Active Trades: " + IntegerToString(openTrades) + " / " + IntegerToString(InpMaxOpenPositions) + "\n";
   text += " Current Spread:" + IntegerToString(symbolInfo.Spread()) + " pts (Max: " + IntegerToString(InpMaxSpreadPoints) + ")\n";
   text += " News Filter:   " + (InpEnableNewsFilter ? "ON" : "OFF") + "\n";
   text += " Strategy:      EMA(" + IntegerToString(InpFastEmaPeriod) + "/" + IntegerToString(InpSlowEmaPeriod) + 
           ") + EMA(" + IntegerToString(InpTrendEmaPeriod) + ") + RSI(" + IntegerToString(InpRsiPeriod) + ")\n";
   text += "========================================";

   Comment(text);
}
//+------------------------------------------------------------------+
""".trimIndent()
  }
}
